
import UIKit

//var greeting = "Hello, playground"

var x: String = "28"

let y = 18

var z:Float = 0.45

var numArray = [1, 2, 3, 4, 5, 6]

var isDirty = true

//x = 15

//print(x)

isDirty = false

if isDirty {
    print("kom inn")
}
else {
    print("Du har ikke lov!")
}

for value in 0...12 {
    print(value)
}


for verdi in numArray {
    if verdi == 5 {
        print("verdi til item er: 5")
    }
    else {
        
        print("verdi til item er ikke 5")
    }
}
    

